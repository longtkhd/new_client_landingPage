var __wpo = {
  "assets": {
    "main": [
      "/d49c034ff7942ecaabdb3020525b1f7e.jpg",
      "/37adff955fb191d757ee692e981c95d8.png",
      "/e2b503727adf7d3697f4a23a0e0d2918.jpg",
      "/beeadcc74c80e9c7acbc04ccb07f6877.png",
      "/06dfd216fc725007d57f97bd951d5a82.jpg",
      "/99d7d7d794ba022b304fb86cefdf9ba8.png",
      "/9fbc9361fbc13040f04008c580960989.jpg",
      "/317f23ea6ce530155dcf7200bb8ce273.jpg",
      "/9fd58175f49f2281e0b78e91dd48bdea.jpg",
      "/b298fcc1e1e7f610b6c7fdc672328dba.png",
      "/3a3b49bbaba2f7cf9ce01e9c9f22ad15.png",
      "/7428e91c2908b74c50d717a8604399d0.png",
      "/32abea3c019153462cadf75ed438ac8f.png",
      "/9c73ca784b40e83125eb9176602eafd1.png",
      "/6d55b214287b97e380a62db174e91332.png",
      "/a48a71c367238c79cad9729542b69e12.jpg",
      "/4687d2dff67df9a42748e6c5080d793f.png",
      "/4738b0410240c3f8cc3011bc66d89630.jpg",
      "/3682436f09ecc5916b403ff39cf031ba.png",
      "/ed23534bf8393d1400c4bf4d76308230.jpg",
      "/2ae0e6e9459f9b4160ae92ed9216e858.png",
      "/73564913de6236214a0d1e4f32c1bd26.jpg",
      "/fdb32b93ac1689528d20bc6bf0226ad6.png",
      "/logo-02.png",
      "/5c718245140929500904f8f704f4183e.png",
      "/c92c1425adc0bbba9869e07b5072fb6c.png",
      "/f2237eae8cdb5674c28cf88640b610f3.png",
      "/eb40dc2dee81025c964e4e13df9470d0.jpg",
      "/876094db74f9695631f9cb87335579e0.jpg",
      "/affef783749affe8c712d29bef7cd439.jpg",
      "/32e50dc4f8da6e1810fdc6c89dd27334.jpg",
      "/82e7a1ec015f6d4da94b7751f52e96e1.png",
      "/fe975c7eb1f94a9213de61538a9c8022.jpg",
      "/runtime.8e97fa6ff3c87882c8ed.js",
      "/"
    ],
    "additional": [
      "/npm.webpack.236f442153b9af7f5d1c.chunk.js",
      "/npm.hoist-non-react-statics.60a51d4b254b610bd89b.chunk.js",
      "/npm.lodash.add45c190ddce4774896.chunk.js",
      "/npm.redux-saga.dd02ccee21b70de90675.chunk.js",
      "/npm.intl.35acf79a26cecc726e06.chunk.js",
      "/npm.material-ui.a95ea939ab758931ee3e.chunk.js",
      "/main.3b1b2e8ce50af611c4f5.chunk.js",
      "/npm.babel.82ed3208526a3946baeb.chunk.js",
      "/npm.connected-react-router.f2647b895c70b823924b.chunk.js",
      "/npm.core-js.4e64fa988d5f8601292d.chunk.js",
      "/npm.react-app-polyfill.1c85ea4a4c368d6cb69a.chunk.js",
      "/npm.react-redux.32275a9471645b5c4fc1.chunk.js",
      "/npm.react-transition-group.7f7a529cc89416ee3142.chunk.js",
      "/14.f3b2654899851cf64775.chunk.js",
      "/15.7adb685395f0266099c7.chunk.js",
      "/16.8590c3f8c6fc94151f4a.chunk.js",
      "/17.ab1b2c40555251dedf8d.chunk.js",
      "/18.d86c0fac9edd03621143.chunk.js",
      "/19.55ffdebd5cd6b982ca09.chunk.js",
      "/20.43db3f98e8eaf73c6acf.chunk.js",
      "/21.0475f0245cd360367f24.chunk.js",
      "/22.d5e36c8590865c379ad0.chunk.js"
    ],
    "optional": []
  },
  "externals": [],
  "hashesMap": {
    "322fe6d151d9c14bf33aa3c86cd9d0ffa943f8b1": "/d49c034ff7942ecaabdb3020525b1f7e.jpg",
    "4d9edd0c74782f51886bad2d97db3ca0d8d013fe": "/37adff955fb191d757ee692e981c95d8.png",
    "59ac4578755642dafdd50192a6643b322bfe8c53": "/e2b503727adf7d3697f4a23a0e0d2918.jpg",
    "a9288badd8b4a5d566aba9085f1f7e5cdc7c8f86": "/beeadcc74c80e9c7acbc04ccb07f6877.png",
    "ddb4cf762b398e3e5dfb2dd92cdfcb4756605e56": "/06dfd216fc725007d57f97bd951d5a82.jpg",
    "2500dfd3ee619e9b587e2787d638ee7b4125bd77": "/99d7d7d794ba022b304fb86cefdf9ba8.png",
    "906de1ecf5eb578668394fe5140a882192e5e2bb": "/9fbc9361fbc13040f04008c580960989.jpg",
    "57d15b773eb65eb7483d1ac6e6f7affa147a1a9e": "/317f23ea6ce530155dcf7200bb8ce273.jpg",
    "cb8b0f45d7465fb193b0354baa7083d1a716c2c5": "/9fd58175f49f2281e0b78e91dd48bdea.jpg",
    "49c804687bfdf230c0104ef674d4cdd4d82172b8": "/b298fcc1e1e7f610b6c7fdc672328dba.png",
    "772cb979f1df55006284293427a1e97d68308290": "/3a3b49bbaba2f7cf9ce01e9c9f22ad15.png",
    "5d7f679a5324a4f1ae525cfe7973272e94becdab": "/7428e91c2908b74c50d717a8604399d0.png",
    "35919ed1e9187a5fdc0b4db76e2e197b45b3effc": "/32abea3c019153462cadf75ed438ac8f.png",
    "bae904b1160bf88fd724385d2b5492a643ee1479": "/9c73ca784b40e83125eb9176602eafd1.png",
    "8a43d46a8ce5a3f82b560d57ac026f8360ac45c1": "/6d55b214287b97e380a62db174e91332.png",
    "295339e6918122f82b8c46a78d98f1812da9e622": "/a48a71c367238c79cad9729542b69e12.jpg",
    "ddfb2c98b9afb1c6d438bff685f371bf4eaa45f9": "/4687d2dff67df9a42748e6c5080d793f.png",
    "d5c08bcb786bf0d578bcfd488572d36b4eda304c": "/4738b0410240c3f8cc3011bc66d89630.jpg",
    "ddbbf89aa469e8e18b99234d59ef6e14e983ed1d": "/3682436f09ecc5916b403ff39cf031ba.png",
    "0c5447c1762f79d95b46c4eb63960b14d0975f73": "/ed23534bf8393d1400c4bf4d76308230.jpg",
    "5cc855114ccc7018620954e8d892ec875b8f02b5": "/2ae0e6e9459f9b4160ae92ed9216e858.png",
    "059e190fb52db0bbe001bc736230a64d50c21069": "/73564913de6236214a0d1e4f32c1bd26.jpg",
    "b5204cee3b55b18185c79a665b014b7d99638ad3": "/fdb32b93ac1689528d20bc6bf0226ad6.png",
    "d2b194c4c14208cced46a45ccab7c257dfe34b21": "/logo-02.png",
    "1a5e7f15e4db7cf9a76df03cd30feaf0d701ce67": "/5c718245140929500904f8f704f4183e.png",
    "d4c043f429350523777d9311eefd40dd0085cd53": "/c92c1425adc0bbba9869e07b5072fb6c.png",
    "36669dcdd6408fa59e96d7176ce2f7108c8d27b5": "/f2237eae8cdb5674c28cf88640b610f3.png",
    "9537577693eb05d65dc9937cd6ff463b6b33642d": "/eb40dc2dee81025c964e4e13df9470d0.jpg",
    "c2bacf177615b4be15f121e6d8261b5f5f460fab": "/876094db74f9695631f9cb87335579e0.jpg",
    "72fc2ccac002ff9bf8a330b524eaea78c5a3224a": "/affef783749affe8c712d29bef7cd439.jpg",
    "4ace19a48a9a40ef377e0b3a388fbafbfbf75a4b": "/32e50dc4f8da6e1810fdc6c89dd27334.jpg",
    "09437cc066706e053b202ad744ab19ef19ca06e4": "/82e7a1ec015f6d4da94b7751f52e96e1.png",
    "049cc78cbd600ef636f458ac5c142fe71549a2ec": "/fe975c7eb1f94a9213de61538a9c8022.jpg",
    "61a83455139529287b5c704d1c2694c52e09bcee": "/npm.webpack.236f442153b9af7f5d1c.chunk.js",
    "e5193bb194415782f0cb63747e511bd19111cb77": "/npm.hoist-non-react-statics.60a51d4b254b610bd89b.chunk.js",
    "2292c6ce3b5e909d2deb073787f607f6bc257f09": "/npm.lodash.add45c190ddce4774896.chunk.js",
    "f8b4d6337ed49eb7e95e4256ee834dcba05e3443": "/npm.redux-saga.dd02ccee21b70de90675.chunk.js",
    "509ecd96cded1e009c2c670a4f985ecd81ed600c": "/npm.intl.35acf79a26cecc726e06.chunk.js",
    "3fef23c125e6c8b0d6d03d9fd37f42598418e8a7": "/npm.material-ui.a95ea939ab758931ee3e.chunk.js",
    "9bef55123147f7c7d4935576f8781af5c7f5dcdd": "/main.3b1b2e8ce50af611c4f5.chunk.js",
    "eb3450d176201f9c5a922762d4e12bfabc02939e": "/npm.babel.82ed3208526a3946baeb.chunk.js",
    "1780845b495b4f29c381635f1ab26659bb3205a7": "/npm.connected-react-router.f2647b895c70b823924b.chunk.js",
    "07b60957acc6eb9e81e345e58d7ebf9b6927b025": "/npm.core-js.4e64fa988d5f8601292d.chunk.js",
    "1628afd7e3d188634c4aa0b2d27ea5e7f59a08fd": "/npm.react-app-polyfill.1c85ea4a4c368d6cb69a.chunk.js",
    "0cbfd34aad72690fd76248e758eb974574732dc9": "/npm.react-redux.32275a9471645b5c4fc1.chunk.js",
    "0a3d1bf72c689257808842393c202c8e55f0f3b4": "/npm.react-transition-group.7f7a529cc89416ee3142.chunk.js",
    "63f621e21cdcf3ee14bcf00e1945aa606867a525": "/runtime.8e97fa6ff3c87882c8ed.js",
    "7a2a65b782bd20dd106582a6d7e8465b895a756f": "/14.f3b2654899851cf64775.chunk.js",
    "9920f6694ff2f31ffbc67f833dfa9aa52c0bffca": "/15.7adb685395f0266099c7.chunk.js",
    "6b80c87780a034afbbec5d9cfebd58a3cfd16af6": "/16.8590c3f8c6fc94151f4a.chunk.js",
    "d87c82c432ac27c107895e7f1433685c952906ca": "/17.ab1b2c40555251dedf8d.chunk.js",
    "07c80fd1ff4e8c9d208e1b99e2256bfe126b6277": "/18.d86c0fac9edd03621143.chunk.js",
    "78c364727c303b2756268b515776740053c848ea": "/19.55ffdebd5cd6b982ca09.chunk.js",
    "69f69372f7f653a9a8a92cc54aa754eac14f02c0": "/20.43db3f98e8eaf73c6acf.chunk.js",
    "dcdb7ba732df9782bf4a87a03026e07a3d8910fa": "/21.0475f0245cd360367f24.chunk.js",
    "3e18330b43520289f0ab27dd109feca002694982": "/22.d5e36c8590865c379ad0.chunk.js",
    "98d6bf6cab898404f802e41851181596fdcb6da6": "/"
  },
  "strategy": "changed",
  "responseStrategy": "cache-first",
  "version": "8/14/2020, 1:54:46 PM",
  "name": "webpack-offline",
  "pluginVersion": "5.0.6",
  "relativePaths": false
};

/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "/";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "22249e1ea7baa06e7c1b");
/******/ })
/************************************************************************/
/******/ ({

/***/ "22249e1ea7baa06e7c1b":
/***/ (function(module, exports, __webpack_require__) {

"use strict";


(function () {
  var waitUntil = ExtendableEvent.prototype.waitUntil;
  var respondWith = FetchEvent.prototype.respondWith;
  var promisesMap = new WeakMap();

  ExtendableEvent.prototype.waitUntil = function (promise) {
    var extendableEvent = this;
    var promises = promisesMap.get(extendableEvent);

    if (promises) {
      promises.push(Promise.resolve(promise));
      return;
    }

    promises = [Promise.resolve(promise)];
    promisesMap.set(extendableEvent, promises);

    // call original method
    return waitUntil.call(extendableEvent, Promise.resolve().then(function processPromises() {
      var len = promises.length;

      // wait for all to settle
      return Promise.all(promises.map(function (p) {
        return p["catch"](function () {});
      })).then(function () {
        // have new items been added? If so, wait again
        if (promises.length != len) return processPromises();
        // we're done!
        promisesMap["delete"](extendableEvent);
        // reject if one of the promises rejected
        return Promise.all(promises);
      });
    }));
  };

  FetchEvent.prototype.respondWith = function (promise) {
    this.waitUntil(promise);
    return respondWith.call(this, promise);
  };
})();;
        'use strict';

if (typeof DEBUG === 'undefined') {
  var DEBUG = false;
}

function WebpackServiceWorker(params, helpers) {
  var cacheMaps = helpers.cacheMaps;
  // navigationPreload: true, { map: (URL) => URL, test: (URL) => boolean }
  var navigationPreload = helpers.navigationPreload;

  // (update)strategy: changed, all
  var strategy = params.strategy;
  // responseStrategy: cache-first, network-first
  var responseStrategy = params.responseStrategy;

  var assets = params.assets;

  var hashesMap = params.hashesMap;
  var externals = params.externals;

  var prefetchRequest = params.prefetchRequest || {
    credentials: 'same-origin',
    mode: 'cors'
  };

  var CACHE_PREFIX = params.name;
  var CACHE_TAG = params.version;
  var CACHE_NAME = CACHE_PREFIX + ':' + CACHE_TAG;

  var PRELOAD_CACHE_NAME = CACHE_PREFIX + '$preload';
  var STORED_DATA_KEY = '__offline_webpack__data';

  mapAssets();

  var allAssets = [].concat(assets.main, assets.additional, assets.optional);

  self.addEventListener('install', function (event) {
    console.log('[SW]:', 'Install event');

    var installing = undefined;

    if (strategy === 'changed') {
      installing = cacheChanged('main');
    } else {
      installing = cacheAssets('main');
    }

    event.waitUntil(installing);
  });

  self.addEventListener('activate', function (event) {
    console.log('[SW]:', 'Activate event');

    var activation = cacheAdditional();

    // Delete all assets which name starts with CACHE_PREFIX and
    // is not current cache (CACHE_NAME)
    activation = activation.then(storeCacheData);
    activation = activation.then(deleteObsolete);
    activation = activation.then(function () {
      if (self.clients && self.clients.claim) {
        return self.clients.claim();
      }
    });

    if (navigationPreload && self.registration.navigationPreload) {
      activation = Promise.all([activation, self.registration.navigationPreload.enable()]);
    }

    event.waitUntil(activation);
  });

  function cacheAdditional() {
    if (!assets.additional.length) {
      return Promise.resolve();
    }

    if (DEBUG) {
      console.log('[SW]:', 'Caching additional');
    }

    var operation = undefined;

    if (strategy === 'changed') {
      operation = cacheChanged('additional');
    } else {
      operation = cacheAssets('additional');
    }

    // Ignore fail of `additional` cache section
    return operation['catch'](function (e) {
      console.error('[SW]:', 'Cache section `additional` failed to load');
    });
  }

  function cacheAssets(section) {
    var batch = assets[section];

    return caches.open(CACHE_NAME).then(function (cache) {
      return addAllNormalized(cache, batch, {
        bust: params.version,
        request: prefetchRequest,
        failAll: section === 'main'
      });
    }).then(function () {
      logGroup('Cached assets: ' + section, batch);
    })['catch'](function (e) {
      console.error(e);
      throw e;
    });
  }

  function cacheChanged(section) {
    return getLastCache().then(function (args) {
      if (!args) {
        return cacheAssets(section);
      }

      var lastCache = args[0];
      var lastKeys = args[1];
      var lastData = args[2];

      var lastMap = lastData.hashmap;
      var lastVersion = lastData.version;

      if (!lastData.hashmap || lastVersion === params.version) {
        return cacheAssets(section);
      }

      var lastHashedAssets = Object.keys(lastMap).map(function (hash) {
        return lastMap[hash];
      });

      var lastUrls = lastKeys.map(function (req) {
        var url = new URL(req.url);
        url.search = '';
        url.hash = '';

        return url.toString();
      });

      var sectionAssets = assets[section];
      var moved = [];
      var changed = sectionAssets.filter(function (url) {
        if (lastUrls.indexOf(url) === -1 || lastHashedAssets.indexOf(url) === -1) {
          return true;
        }

        return false;
      });

      Object.keys(hashesMap).forEach(function (hash) {
        var asset = hashesMap[hash];

        // Return if not in sectionAssets or in changed or moved array
        if (sectionAssets.indexOf(asset) === -1 || changed.indexOf(asset) !== -1 || moved.indexOf(asset) !== -1) return;

        var lastAsset = lastMap[hash];

        if (lastAsset && lastUrls.indexOf(lastAsset) !== -1) {
          moved.push([lastAsset, asset]);
        } else {
          changed.push(asset);
        }
      });

      logGroup('Changed assets: ' + section, changed);
      logGroup('Moved assets: ' + section, moved);

      var movedResponses = Promise.all(moved.map(function (pair) {
        return lastCache.match(pair[0]).then(function (response) {
          return [pair[1], response];
        });
      }));

      return caches.open(CACHE_NAME).then(function (cache) {
        var move = movedResponses.then(function (responses) {
          return Promise.all(responses.map(function (pair) {
            return cache.put(pair[0], pair[1]);
          }));
        });

        return Promise.all([move, addAllNormalized(cache, changed, {
          bust: params.version,
          request: prefetchRequest,
          failAll: section === 'main',
          deleteFirst: section !== 'main'
        })]);
      });
    });
  }

  function deleteObsolete() {
    return caches.keys().then(function (keys) {
      var all = keys.map(function (key) {
        if (key.indexOf(CACHE_PREFIX) !== 0 || key.indexOf(CACHE_NAME) === 0) return;

        console.log('[SW]:', 'Delete cache:', key);
        return caches['delete'](key);
      });

      return Promise.all(all);
    });
  }

  function getLastCache() {
    return caches.keys().then(function (keys) {
      var index = keys.length;
      var key = undefined;

      while (index--) {
        key = keys[index];

        if (key.indexOf(CACHE_PREFIX) === 0) {
          break;
        }
      }

      if (!key) return;

      var cache = undefined;

      return caches.open(key).then(function (_cache) {
        cache = _cache;
        return _cache.match(new URL(STORED_DATA_KEY, location).toString());
      }).then(function (response) {
        if (!response) return;

        return Promise.all([cache, cache.keys(), response.json()]);
      });
    });
  }

  function storeCacheData() {
    return caches.open(CACHE_NAME).then(function (cache) {
      var data = new Response(JSON.stringify({
        version: params.version,
        hashmap: hashesMap
      }));

      return cache.put(new URL(STORED_DATA_KEY, location).toString(), data);
    });
  }

  self.addEventListener('fetch', function (event) {
    // Handle only GET requests
    if (event.request.method !== 'GET') {
      return;
    }

    // This prevents some weird issue with Chrome DevTools and 'only-if-cached'
    // Fixes issue #385, also ref to:
    // - https://github.com/paulirish/caltrainschedule.io/issues/49
    // - https://bugs.chromium.org/p/chromium/issues/detail?id=823392
    if (event.request.cache === 'only-if-cached' && event.request.mode !== 'same-origin') {
      return;
    }

    var url = new URL(event.request.url);
    url.hash = '';

    var urlString = url.toString();

    // Not external, so search part of the URL should be stripped,
    // if it's external URL, the search part should be kept
    if (externals.indexOf(urlString) === -1) {
      url.search = '';
      urlString = url.toString();
    }

    var assetMatches = allAssets.indexOf(urlString) !== -1;
    var cacheUrl = urlString;

    if (!assetMatches) {
      var cacheRewrite = matchCacheMap(event.request);

      if (cacheRewrite) {
        cacheUrl = cacheRewrite;
        assetMatches = true;
      }
    }

    if (!assetMatches) {
      // Use request.mode === 'navigate' instead of isNavigateRequest
      // because everything what supports navigationPreload supports
      // 'navigate' request.mode
      if (event.request.mode === 'navigate') {
        // Requesting with fetchWithPreload().
        // Preload is used only if navigationPreload is enabled and
        // navigationPreload mapping is not used.
        if (navigationPreload === true) {
          event.respondWith(fetchWithPreload(event));
          return;
        }
      }

      // Something else, positive, but not `true`
      if (navigationPreload) {
        var preloadedResponse = retrivePreloadedResponse(event);

        if (preloadedResponse) {
          event.respondWith(preloadedResponse);
          return;
        }
      }

      // Logic exists here if no cache match
      return;
    }

    // Cache handling/storing/fetching starts here
    var resource = undefined;

    if (responseStrategy === 'network-first') {
      resource = networkFirstResponse(event, urlString, cacheUrl);
    }
    // 'cache-first' otherwise
    // (responseStrategy has been validated before)
    else {
        resource = cacheFirstResponse(event, urlString, cacheUrl);
      }

    event.respondWith(resource);
  });

  self.addEventListener('message', function (e) {
    var data = e.data;
    if (!data) return;

    switch (data.action) {
      case 'skipWaiting':
        {
          if (self.skipWaiting) self.skipWaiting();
        }break;
    }
  });

  function cacheFirstResponse(event, urlString, cacheUrl) {
    handleNavigationPreload(event);

    return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
      if (response) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + cacheUrl + '](' + urlString + ') from cache');
        }

        return response;
      }

      // Load and cache known assets
      var fetching = fetch(event.request).then(function (response) {
        if (!response.ok) {
          if (DEBUG) {
            console.log('[SW]:', 'URL [' + urlString + '] wrong response: [' + response.status + '] ' + response.type);
          }

          return response;
        }

        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        if (cacheUrl === urlString) {
          (function () {
            var responseClone = response.clone();
            var storing = caches.open(CACHE_NAME).then(function (cache) {
              return cache.put(urlString, responseClone);
            }).then(function () {
              console.log('[SW]:', 'Cache asset: ' + urlString);
            });

            event.waitUntil(storing);
          })();
        }

        return response;
      });

      return fetching;
    });
  }

  function networkFirstResponse(event, urlString, cacheUrl) {
    return fetchWithPreload(event).then(function (response) {
      if (response.ok) {
        if (DEBUG) {
          console.log('[SW]:', 'URL [' + urlString + '] from network');
        }

        return response;
      }

      // Throw to reach the code in the catch below
      throw response;
    })
    // This needs to be in a catch() and not just in the then() above
    // cause if your network is down, the fetch() will throw
    ['catch'](function (erroredResponse) {
      if (DEBUG) {
        console.log('[SW]:', 'URL [' + urlString + '] from cache if possible');
      }

      return cachesMatch(cacheUrl, CACHE_NAME).then(function (response) {
        if (response) {
          return response;
        }

        if (erroredResponse instanceof Response) {
          return erroredResponse;
        }

        // Not a response at this point, some other error
        throw erroredResponse;
        // return Response.error();
      });
    });
  }

  function handleNavigationPreload(event) {
    if (navigationPreload && typeof navigationPreload.map === 'function' &&
    // Use request.mode === 'navigate' instead of isNavigateRequest
    // because everything what supports navigationPreload supports
    // 'navigate' request.mode
    event.preloadResponse && event.request.mode === 'navigate') {
      var mapped = navigationPreload.map(new URL(event.request.url), event.request);

      if (mapped) {
        storePreloadedResponse(mapped, event);
      }
    }
  }

  // Temporary in-memory store for faster access
  var navigationPreloadStore = new Map();

  function storePreloadedResponse(_url, event) {
    var url = new URL(_url, location);
    var preloadResponsePromise = event.preloadResponse;

    navigationPreloadStore.set(preloadResponsePromise, {
      url: url,
      response: preloadResponsePromise
    });

    var isSamePreload = function isSamePreload() {
      return navigationPreloadStore.has(preloadResponsePromise);
    };

    var storing = preloadResponsePromise.then(function (res) {
      // Return if preload isn't enabled or hasn't happened
      if (!res) return;

      // If navigationPreloadStore already consumed
      // or navigationPreloadStore already contains another preload,
      // then do not store anything and return
      if (!isSamePreload()) {
        return;
      }

      var clone = res.clone();

      // Storing the preload response for later consume (hasn't yet been consumed)
      return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        if (!isSamePreload()) return;

        return cache.put(url, clone).then(function () {
          if (!isSamePreload()) {
            return caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
              return cache['delete'](url);
            });
          }
        });
      });
    });

    event.waitUntil(storing);
  }

  function retriveInMemoryPreloadedResponse(url) {
    if (!navigationPreloadStore) {
      return;
    }

    var foundResponse = undefined;
    var foundKey = undefined;

    navigationPreloadStore.forEach(function (store, key) {
      if (store.url.href === url.href) {
        foundResponse = store.response;
        foundKey = key;
      }
    });

    if (foundResponse) {
      navigationPreloadStore['delete'](foundKey);
      return foundResponse;
    }
  }

  function retrivePreloadedResponse(event) {
    var url = new URL(event.request.url);

    if (self.registration.navigationPreload && navigationPreload && navigationPreload.test && navigationPreload.test(url, event.request)) {} else {
      return;
    }

    var fromMemory = retriveInMemoryPreloadedResponse(url);
    var request = event.request;

    if (fromMemory) {
      event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
        return cache['delete'](request);
      }));

      return fromMemory;
    }

    return cachesMatch(request, PRELOAD_CACHE_NAME).then(function (response) {
      if (response) {
        event.waitUntil(caches.open(PRELOAD_CACHE_NAME).then(function (cache) {
          return cache['delete'](request);
        }));
      }

      return response || fetch(event.request);
    });
  }

  function mapAssets() {
    Object.keys(assets).forEach(function (key) {
      assets[key] = assets[key].map(function (path) {
        var url = new URL(path, location);

        url.hash = '';

        if (externals.indexOf(path) === -1) {
          url.search = '';
        }

        return url.toString();
      });
    });

    hashesMap = Object.keys(hashesMap).reduce(function (result, hash) {
      var url = new URL(hashesMap[hash], location);
      url.search = '';
      url.hash = '';

      result[hash] = url.toString();
      return result;
    }, {});

    externals = externals.map(function (path) {
      var url = new URL(path, location);
      url.hash = '';

      return url.toString();
    });
  }

  function addAllNormalized(cache, requests, options) {
    var bustValue = options.bust;
    var failAll = options.failAll !== false;
    var deleteFirst = options.deleteFirst === true;
    var requestInit = options.request || {
      credentials: 'omit',
      mode: 'cors'
    };

    var deleting = Promise.resolve();

    if (deleteFirst) {
      deleting = Promise.all(requests.map(function (request) {
        return cache['delete'](request)['catch'](function () {});
      }));
    }

    return Promise.all(requests.map(function (request) {
      if (bustValue) {
        request = applyCacheBust(request, bustValue);
      }

      return fetch(request, requestInit).then(fixRedirectedResponse).then(function (response) {
        if (!response.ok) {
          return { error: true };
        }

        return { response: response };
      }, function () {
        return { error: true };
      });
    })).then(function (responses) {
      if (failAll && responses.some(function (data) {
        return data.error;
      })) {
        return Promise.reject(new Error('Wrong response status'));
      }

      if (!failAll) {
        responses = responses.filter(function (data) {
          return !data.error;
        });
      }

      return deleting.then(function () {
        var addAll = responses.map(function (_ref, i) {
          var response = _ref.response;

          return cache.put(requests[i], response);
        });

        return Promise.all(addAll);
      });
    });
  }

  function matchCacheMap(request) {
    var urlString = request.url;
    var url = new URL(urlString);

    var requestType = undefined;

    if (isNavigateRequest(request)) {
      requestType = 'navigate';
    } else if (url.origin === location.origin) {
      requestType = 'same-origin';
    } else {
      requestType = 'cross-origin';
    }

    for (var i = 0; i < cacheMaps.length; i++) {
      var map = cacheMaps[i];

      if (!map) continue;
      if (map.requestTypes && map.requestTypes.indexOf(requestType) === -1) {
        continue;
      }

      var newString = undefined;

      if (typeof map.match === 'function') {
        newString = map.match(url, request);
      } else {
        newString = urlString.replace(map.match, map.to);
      }

      if (newString && newString !== urlString) {
        return newString;
      }
    }
  }

  function fetchWithPreload(event) {
    if (!event.preloadResponse || navigationPreload !== true) {
      return fetch(event.request);
    }

    return event.preloadResponse.then(function (response) {
      return response || fetch(event.request);
    });
  }
}

function cachesMatch(request, cacheName) {
  return caches.match(request, {
    cacheName: cacheName
  }).then(function (response) {
    if (isNotRedirectedResponse(response)) {
      return response;
    }

    // Fix already cached redirected responses
    return fixRedirectedResponse(response).then(function (fixedResponse) {
      return caches.open(cacheName).then(function (cache) {
        return cache.put(request, fixedResponse);
      }).then(function () {
        return fixedResponse;
      });
    });
  })
  // Return void if error happened (cache not found)
  ['catch'](function () {});
}

function applyCacheBust(asset, key) {
  var hasQuery = asset.indexOf('?') !== -1;
  return asset + (hasQuery ? '&' : '?') + '__uncache=' + encodeURIComponent(key);
}

function isNavigateRequest(request) {
  return request.mode === 'navigate' || request.headers.get('Upgrade-Insecure-Requests') || (request.headers.get('Accept') || '').indexOf('text/html') !== -1;
}

function isNotRedirectedResponse(response) {
  return !response || !response.redirected || !response.ok || response.type === 'opaqueredirect';
}

// Based on https://github.com/GoogleChrome/sw-precache/pull/241/files#diff-3ee9060dc7a312c6a822cac63a8c630bR85
function fixRedirectedResponse(response) {
  if (isNotRedirectedResponse(response)) {
    return Promise.resolve(response);
  }

  var body = 'body' in response ? Promise.resolve(response.body) : response.blob();

  return body.then(function (data) {
    return new Response(data, {
      headers: response.headers,
      status: response.status
    });
  });
}

function copyObject(original) {
  return Object.keys(original).reduce(function (result, key) {
    result[key] = original[key];
    return result;
  }, {});
}

function logGroup(title, assets) {
  console.groupCollapsed('[SW]:', title);

  assets.forEach(function (asset) {
    console.log('Asset:', asset);
  });

  console.groupEnd();
}
        WebpackServiceWorker(__wpo, {
loaders: {},
cacheMaps: [
      {
      match: function(url) {
          if (url.pathname === location.pathname) {
            return;
          }

          return new URL("/", location);
        },
      to: null,
      requestTypes: ["navigate"],
    }
    ],
navigationPreload: false,
});
        module.exports = __webpack_require__("6872a71ed75a597694c7")
      

/***/ }),

/***/ "6872a71ed75a597694c7":
/***/ (function(module, exports) {



/***/ })

/******/ });